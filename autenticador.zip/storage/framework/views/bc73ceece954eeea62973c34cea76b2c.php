<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Principal</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/btn.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/reset.css')); ?>">
</head>

<body>
    <div class="container">
        <div class="content">
            <div class="imagem">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" srcset="">
            </div>
            <button class="ui-btn">
                <span>
                  <a href="<?php echo e(route('site.login')); ?>">Login</a>
                </span>
              </button>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\laracode\autenticador\resources\views\site\index.blade.php ENDPATH**/ ?>