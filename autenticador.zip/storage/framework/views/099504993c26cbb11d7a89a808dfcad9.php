<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/reset.css')); ?>">
    <title>Dash</title>
</head>

<body>
    <div class="container">
        <div class="content">
            <h1>Painel de controle - Serralheria</h1>

            <?php if(isset($credenciais)): ?>
                <p>Email: <?php echo e($credenciais['email']); ?></p>
            <?php endif; ?>
        </div>
        <a href="<?php echo e(route('site.logout')); ?>" class="">Logout</a>
    </div>
</body>

</html>
<?php /**PATH C:\laracode\autenticador\resources\views\app\dash\index.blade.php ENDPATH**/ ?>