<h1>PAGE 404</h1>
<?php /**PATH C:\laracode\autenticador\resources\views\site\404.blade.php ENDPATH**/ ?>